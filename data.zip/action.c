Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_url("dns-query", 
		"URL=https://dns.google/dns-query?dns=AAABAAABAAAAAAABA3d3dwdnc3RhdGljA2NvbQAAAQABAAApEAAAAAAAAFQADABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 
		"Resource=1", 
		"RecContentType=application/dns-message", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	web_url("dns-query_2", 
		"URL=https://dns.google/dns-query?dns=AAABAAABAAAAAAABA3d3dwdnc3RhdGljA2NvbQAAAQABAAApEAAAAAAAAFQADABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 
		"Resource=1", 
		"RecContentType=application/dns-message", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=94", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("slovardalja.net", 
		"URL=http://slovardalja.net/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://dns.google/dns-query?dns=AAABAAABAAAAAAABA3d3dwdnc3RhdGljA2NvbQAAAQABAAApEAAAAAAAAFQADABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		"Url=https://dns.google/dns-query?dns=AAABAAABAAAAAAABBm5ld3JyYgNiaWQAAAEAAQAAKRAAAAAAAABZAAwAVQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		"Url=https://www.google-analytics.com/urchin.js", ENDITEM, 
		"Url=https://counter.yadro.ru/hit?q;t44.1;r;s1920*1080*24;uhttp%3A//slovardalja.net/;h%u0422%u043E%u043B%u043A%u043E%u0432%u044B%u0439%20%u0441%u043B%u043E%u0432%u0430%u0440%u044C%20%u0414%u0430%u043B%u044F%20%u043E%u043D%u043B%u0430%u0439%u043D;0.3940501010795656", ENDITEM, 
		"Url=https://counter.yadro.ru/hit?q;t44.1;rhttp%3A//slovardalja.net/;s1920*1080*24;uhttp%3A//slovardalja.net/letter.php%3Fcharkod%3D202;h%u0422%u043E%u043B%u043A%u043E%u0432%u044B%u0439%20%u0441%u043B%u043E%u0432%u0430%u0440%u044C%20%u0414%u0430%u043B%u044F%20%u043E%u043D%u043B%u0430%u0439%u043D;0.1782950235486509", ENDITEM, 
		"Url=https://counter.yadro.ru/hit?q;t44.1;rhttp%3A//slovardalja.net/letter.php%3Fcharkod%3D202;s1920*1080*24;uhttp%3A//slovardalja.net/word.php%3Fwordid%3D12491;h%u0422%u043E%u043B%u043A%u043E%u0432%u044B%u0439%20%u0441%u043B%u043E%u0432%u0430%u0440%u044C%20%u0414%u0430%u043B%u044F%20%u043E%u043D%u043B%u0430%u0439%u043D;0.4198842884729179", ENDITEM, 
		LAST);

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_custom_request("chromesync:join", 
		"URL=https://securitydomain-pa.googleapis.com/v1/users/me/securitydomains/chromesync:join?alt=proto", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuf", 
		"BodyBinary=\n%\n#users/me/securitydomains/chromesync\\x12\\xAF\\x01\nhusers/me/members/BLIRJztZMRTfzQHvp8HIERpGLcC4n9gkiulTrGXTGRS4mCRu6EsSuH6T-ruWFmo02LHotFgBQ2y5IzrjkQN8060\\x12A\\x04\\xB2\\x11';Y1\\x14\\xDF\\xCD\\x01\\xEF\\xA7\\xC1\\xC8\\x11\\x1AF-\\xC0\\xB8\\x9F\\xD8$\\x8A\\xE9S\\xACe\\xD3\\x19\\x14\\xB8\\x98$n\\xE8K\\x12\\xB8~\\x93\\xFA\\xBB\\x96\\x16j4\\xD8\\xB1\\xE8\\xB4X\\x01Cl\\xB9#:\\xE3\\x91\\x03|\\xD3\\xAD "
		"\\x01\\x1A\\x93\\x01\\x12o\\x02\\x00\\x04\\xAE\\x9E\\xA9O\\xA7\\xBB\\x0E\\x11\\xB2\\xEF\\xC0&\\x00\\x1C1\\xA4\\xBDS\\xC1\\xDA\\x95\n\\xC5\\xEF\\x8E\\xFB`\\xBA/\\x1F\\x1B\\xF1g\\x9DE\\xD0\\xBB1\\x05}#p\\xB5\\xB6\\x81\\xBE\\xF8qX\\xA3\\xD127k5\\xDF\\xE8\\xB0B\\xD8\\xF0\\xE7;\\xA8\\x97@\\xADl\\xA3\\xB8\\xFBLx\\x8DPk\\xB6\\x10[\\xA5\n\\x03\\x98\\c\\xB6\\xE5\\xB5\\xC7\\\\x0B\\xEE}Sx\naQO\\xEE\\xB9\\xB5\\x1C]\\x94\\x00\\xA8\\xDA\\x1A \\xDF\\xE3\"\\xC3!\\x8A3?"
		"[\\xF0\\xA6\\xEEz\\x84\\x04\\xD6\\xE6b\\x11\\xB0\\x9C1G\\x8A#\\xAC\\xA7\\xB6\\xCF\\xF7\\xBA\\xB3", 
		EXTRARES, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChNDaHJvbWUvOTQuMC40NjA2LjgxEhAJrlVfs5DBJJoSBQ1nZ7P-GKupygE=?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_add_cookie("__utma=196215790.415563117.1634586398.1634586398.1634586398.1; DOMAIN=slovardalja.net");

	web_add_cookie("__utmb=196215790; DOMAIN=slovardalja.net");

	web_add_cookie("__utmc=196215790; DOMAIN=slovardalja.net");

	web_add_cookie("__utmz=196215790.1634586398.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none); DOMAIN=slovardalja.net");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("letter.php", 
		"URL=http://slovardalja.net/letter.php?charkod=202", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://slovardalja.net/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=http://slovardalja.net/letter.php?charkod=202", ENDITEM, 
		LAST);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_link("������", 
		"Text=������", 
		"Snapshot=t7.inf", 
		LAST);

	return 0;
}